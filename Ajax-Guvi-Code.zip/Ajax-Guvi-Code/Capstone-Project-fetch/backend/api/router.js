// maintain all my endpoints here
const express = require('express');
const router = express.Router();


let data=[
    {
        id:'1',
        name:'Anees',
        age:30,
        gender:'Male',
        city:'Bangalore',
        skills:'cricket,vollyball,tennis'
    },
    {
        id:'2',
        name:'Aadithyaa',
        age:25,
        gender:'Male',
        city:'Bangalore',
        skills:'carreom'
    }
];

// GET request
router.get('/sports',(req,res)=>{
    console.log(`GET REQUEST:  ${new Date().toLocaleTimeString()}`)
    res.json(data)
})

let createGID=()=>{
    return (Date.now() + Math.random().toFixed(0));
}
//POST request
router.post('/sports/register',(req,res)=>{
  let newRegister={
    id:createGID(),
    name:req.body.name,
    age:req.body.age,
    gender:req.body.gender,
    city:req.body.city,
    skills:req.body.skills
  }

  data.push(newRegister);
  console.log(`POST REQUEST:  ${new Date().toLocaleTimeString()}`)
    res.json({message:`POST Request is Done`,newRegisteredPerson:newRegister})



})

// PUT Request
router.put('/sports/registerupdate/:id',(req,res)=>{
    let rid=req.params.id;
    let dataUpdate={
        id:rid,
        name:req.body.name,
        age:req.body.age,
        gender:req.body.gender,
        city:req.body.city,
        skills:req.body.skills
    }
    let existingData = data.find((d)=>{
        return d.id===rid
    })

    data.splice(data.indexOf(existingData),1,dataUpdate)

    res.json({message:"PUT Request is Succedd"})

})

// Delete Request

router.delete('/sports/delete/:id',(req,res)=>{
    let did=req.params.id;
    data=data.filter((d)=>{
        return d.id!==did
    })
    res.json({message:'Deleted Successfully'})
})


// search
router.get('/sports/search', (req, res) => {
    const searchTerm = req.query.q;
    console.log(searchTerm)
  
    if (!searchTerm) {
      return res.status(400).json({ error: 'Search term is required.' });
    }
  
    const results = data.filter((item) => {
      return (
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.skills.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  
    res.json(results);
  });
  



module.exports= router;