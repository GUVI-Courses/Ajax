const express = require('express');
const sports=require('./api/router')
const cors = require('cors')

const app=express();
const hostname='127.0.0.1';
const port=3000;

app.listen(port,hostname,()=>{
    console.log(`Server is running at http://${hostname}:${port}`)
})

app.use(cors({
    origin:"*"
}))
app.use(express.json());
app.use('/api',sports);

app.get('/',(req,res)=>{
    res.send(`<h1>Welcome to guvi backend server</h1>`)
})
