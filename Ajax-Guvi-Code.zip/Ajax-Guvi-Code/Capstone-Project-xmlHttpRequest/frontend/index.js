// import { AjaxCall } from '../frontend/api/ajax'
let table = document.getElementById("tableOutput");

const SERVER_URL = "http://127.0.0.1:3000/api";

window.addEventListener("DOMContentLoaded", () => {
  fetchData();
});

// All ajax calls starts here
class AjaxCall {
  constructor() {
    // GET request
    this.get = (url, callback) => {
      const xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          callback(JSON.parse(xhr.responseText));
        }
      };
      xhr.send();
    };

    // POST Request
    this.post = (url, data, callback) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", url, true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          callback(JSON.parse(xhr.responseText));
        }
      };
      xhr.send(JSON.stringify(data));
    };

    // PUT request using XMLHttpRequest
    this.put = (url, updateData, callback) => {
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", url, true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          callback(JSON.parse(xhr.responseText));
        }
      };
      xhr.send(JSON.stringify(updateData));
    };

    // Delete Request using XMLHttpRequest
    this.delete = (url, callback) => {
      const xhr = new XMLHttpRequest();
      xhr.open("DELETE", url, true);
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          callback(JSON.parse(xhr.responseText));
        }
      };
      xhr.send();
    };
  }
}

// Ajax calls ends here

let fetchData = () => {
  let url = SERVER_URL + "/sports";
  let axios = new AjaxCall();
  axios.get(url, (data) => {
    let tablerows = "";
    for (const d of data) {
      tablerows += `
         <tr>
            <td>${d.id}</td>
            <td>${d.name}</td>
            <td>${d.age}</td>
            <td>${d.gender}</td>
            <td>${d.city}</td>
            <td>${d.skills}</td>
            <td>
              <button type="button" class="btn btn-outline-dark update" data-bs-toggle="modal"
              data-bs-target="#editModal"
              type="button">Edit</button>
            </td>
            <td>
              <button type="button" class="btn btn-outline-danger delete">
                Delete
              </button>
            </td>
          </tr> 
            `;
    }
    table.innerHTML = tablerows;
  });
};

function clearForm() {
  document.getElementById("name").value = "";
  document.getElementById("age").value = "";
  document.getElementById("city").value = "";
  document.getElementById("gender").value = "Select Gender";
  document.getElementById("skills").value = "";
}

// POST Request
let btn = document.getElementById("submitbtn");
btn.addEventListener("click", (e) => {
  e.preventDefault();

  // let create a new object that is new candidate data
  let name = document.getElementById("name").value;
  let age = document.getElementById("age").value;
  let city = document.getElementById("city").value;
  let gender = document.getElementById("gender").value;
  let skills = document.getElementById("skills").value;
  let newData = { name, age, gender, city, skills };
  let url = SERVER_URL + "/sports/register";
  let axios = new AjaxCall();
  axios.post(url, newData, () => {
    fetchData();
    document.getElementById("btn-close").click();
    clearForm();
  });
});

// PUT Request
let tableWrapper = document.getElementById("tableOutput");
tableWrapper.addEventListener("click", (e) => {
  let target = e.target;
  let id = target.parentElement.parentElement.firstElementChild.innerHTML;
  if (target.classList.contains("update")) {
    let url = SERVER_URL + "/sports";
    let axios = new AjaxCall();
    axios.get(url, (data) => {
      let selectedData = data.find((d) => {
        return d.id === id;
      });

      populatedModal(selectedData);
    });
  }
});

let populatedModal = (returnData) => {
  document.getElementById("cid").value = returnData.id;
  document.getElementById("ename").value = returnData.name;
  document.getElementById("eage").value = returnData.age;
  document.getElementById("egender").value = returnData.gender;
  document.getElementById("ecity").value = returnData.city;
  document.getElementById("eskills").value = returnData.skills;
};

// Send request for update modal

let ebtn = document.getElementById("esubmitbtn");
ebtn.addEventListener("click", (e) => {
  e.preventDefault();

  // let create a new object that is new candidate data
  let cid = document.getElementById("cid").value;
  let name = document.getElementById("ename").value;
  let age = document.getElementById("eage").value;
  let city = document.getElementById("ecity").value;
  let gender = document.getElementById("egender").value;
  let skills = document.getElementById("eskills").value;
  let updateData = { name, age, gender, city, skills };
  console.log(updateData);
  let url = SERVER_URL + "/sports/registerupdate/" + cid;
  let axios = new AjaxCall();
  axios.put(url, updateData, () => {
    fetchData();
    document.getElementById("ebtn-close").click();
  });
});

// Delete request
tableWrapper.addEventListener("click", (e) => {
  let target = e.target;
  if (target.classList.contains("delete")) {
    let id = target.parentElement.parentElement.firstElementChild.innerHTML;
    let axios = new AjaxCall();
    let url = SERVER_URL + "/sports/delete/" + id;
    axios.delete(url, () => {
      fetchData();
    });
  }
});

$(document).ready(function () {
  $("#submitbtn").prop("disabled", true);

  $("#FormData input,#FormData select,#FormData textarea").on(
    "input change",
    function () {
      var allFieldsFilled = true;
      $("#FormData input,#FormData select,#FormData textarea").each(
        function () {
          if ($(this).prop("required") && $(this).val() === "") {
            allFieldsFilled = false;
            return false;
          }
        }
      );

      $("#submitbtn").prop("disabled", !allFieldsFilled);
    }
  );

  // edit btn disbale
  $("#esubmitbtn").prop("disabled", true);

  $("#eFormData input,#eFormData select,#eFormData textarea").on(
    "input change",
    function () {
      var eallFieldsFilled = true;
      $("#eFormData input,#eFormData select,#eFormData textarea").each(
        function () {
          if ($(this).prop("required") && $(this).val() === "") {
            eallFieldsFilled = false;
            return false;
          }
        }
      );

      $("#esubmitbtn").prop("disabled", !eallFieldsFilled);
    }
  );
});
